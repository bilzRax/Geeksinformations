emailjs.init("X-Y7bbZrXyDb_H8Ko"); // Replace with your Email.js User ID

document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const subject = document.getElementById("subject").value;
  const message = document.getElementById("message").value;

  const templateParams = {
    name: name,
    email: email,
    subject: subject,
    message: message,
  };

  emailjs.send("service_c773xfm", "template_t1jlc6l", templateParams)
    .then(function (response) {
      alert("Email sent successfully!");
      document.getElementById("contactForm").reset();
    }, function (error) {
      console.error("Error sending email: ", error);
      alert("An error occurred while sending the email.");
    });
});