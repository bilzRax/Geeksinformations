document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
});

document.onkeydown = function (e) {
    e = e || window.event;

    if (e.keyCode == 123) {
        // Prevent F12 key
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
        // Prevent Ctrl+Shift+I
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)) {
        // Prevent Ctrl+Shift+C
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
        // Prevent Ctrl+Shift+J
        return false;
    }

    if (e.ctrlKey && e.keyCode == "U".charCodeAt(0)) {
        // Prevent Ctrl+U
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.altKey) {
        // Prevent Ctrl+Shift+Alt combination
        return false;
    }

    if (e.metaKey) {
        // Prevent Command key (Mac) combinations
        return false;
    }
};
